%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% STOCHASTIC NEOCLASSICAL GROWTH MODEL %%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%--------------------------------------------------------------------------
%
% SOLUTION CODE USING CHEBYSHEV COLLOCATION NODES AND CHEBYSHEV POLYNOMIAL
% APPROXIMATION, WITH FIXED POINT AS WELL AS TIME ITERATION METHODS
%
%--------------------------------------------------------------------------
%
% Author : Anup Mulay (anupmulay1@gmail.com)
%
% Copyright (c) 2015-2026 Anup Mulay. Released under the MIT License (see LICENSE).
%
%--------------------------------------------------------------------------
%   The model
%   ---------
%   A representative household maximises E sum beta^t C_t^(1-nu)/(1-nu)
%   subject to
%
%       K_{t+1} = Z_t K_t^alpha + (1 - delta) K_t - C_t,
%       log Z_{t+1} = rho log Z_t + eps_{t+1},   eps ~ N(0, sigma^2).
%
%   The solution is characterised by the Euler equation
%
%       C_t^(-nu) = beta E_t[ C_{t+1}^(-nu) (1 - delta + alpha Z_{t+1} K_{t+1}^(alpha-1)) ].
%
%   The method
%   ----------
%   The state is s = (k, z) = (log K, log Z). The log of marginal utility
%   of consumption is approximated by a tensor product of Chebyshev
%   polynomials,
%
%       log C(s)^(-nu) ~ Omega(s) * psi,
%
%   and the coefficients psi are found by projection:
%
%     1. Collocation nodes: ord+1 Chebyshev zeros per state (chebgrid.m),
%        all combinations of them (makecombo.m), and the basis matrix
%        Omega at those nodes (scale_poly.m, makepolycheb.m).
%     2. Given psi, compute at every node a new value of marginal utility
%        that satisfies the Euler equation, with the expectation computed
%        by Gauss-Hermite quadrature (hernodes.m). Two variants:
%          soln_meth = 1  TIME ITERATION (timeiter_stoch.m): today's
%                         consumption is solved for with a nonlinear
%                         solver (csolve.m) so that the Euler equation
%                         holds exactly, given tomorrow's policy psi.
%          otherwise      FIXED POINT ITERATION (iterfun_stoch.m): today's
%                         policy comes from psi as well, and the right
%                         hand side of the Euler equation is taken as the
%                         new left hand side. Cheaper per iteration.
%     3. Project the new values onto the basis by least squares,
%        psi_new = (Omega'Omega) \ Omega' log(values), and update with
%        damping, psi = lrate*psi_new + (1 - lrate)*psi, until
%        norm(psi_new - psi) < psitol.
%     4. Simulate the solution and plot it (plotting_determ.m).
%
%   The loop starts from a guess derived from the model, not from a
%   previous solution: consume the steady state share of output at every
%   state, C = (Css/Yss)*Y. Both variants converge to the same
%   coefficients. With the default settings (order 2 in each state,
%   psitol = 1e-10) fixed point iteration needs 618 iterations and time
%   iteration 635. At order 1 in each state they need 677 and 694.
%
%   Orders
%   ------
%   ord_k and ord_z set the order in capital and in technology. They may
%   differ. Everything else, including the size of the starting guess,
%   follows from them.
%
%   Programs used in this code:
%   ---------------------------
%
%       1. chebgrid.m
%       2. makecombo.m
%       3. scale_poly.m
%       4. makepolycheb.m
%       5. hernodes.m
%       6. iterfun_stoch.m
%       7. timeiter_stoch.m
%       8. titer_func.m
%       9. num_int_ti.m
%       10. csolve.m (Christopher Sims, GPL; see the file)
%       11. plotting_determ.m
%
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
%----------------------- SETTING UP THE PROBLEM ---------------------------
%--------------------------------------------------------------------------

% Housekeeping

clear;
close all;
clc;

% Model parameters

par.nu      =   3;
par.alpha   =   0.33;
par.beta    =   0.99;
par.delta   =   0.025;
par.sigma   =   0.0072;
par.rho     =   0.95;

% Convergence parameters

psitol      =   1e-10;      % Convergence criterion on the step
                            % norm(psi_new - psi). The loop converges
                            % slowly (about 3 percent per iteration), so
                            % the error in the coefficients is about 30
                            % times the last step: 1e-10 gives about 3e-9.
lrate       =   0.7;        % Parameter to control updating of coefficient
maxiter     =   20000;      % Maximum iterations for main loop

% Orders of approximation for the two states

ord_k       =   2;
ord_z       =   2;
ord         =   [ord_k ord_z];

% Capital steady state

Kss         =   (par.alpha*par.beta/(1-par.beta*(1-par.delta)))^...
    (1/(1-par.alpha));

% Capital grid range

Klow        =   0.7*Kss;
Khi         =   1.3*Kss;

% Taking logs

klow        =   log(Klow);
khi         =   log(Khi);

% Polynomial coefficients for capital state

k_numb      =   ord_k + 1;  

% Shock grid

zlow        =   -2*par.sigma/(1-par.rho);
zhi         =   2*par.sigma/(1-par.rho);

% Polynomial coefficients for technology state

z_numb      =   ord_z + 1;

% Grid of collocation nodes

k_grid      =   chebgrid(klow,khi,k_numb);

z_grid      =   chebgrid(zlow,zhi,z_numb);

% All possible grid point combinations for the two states. The function
% makecombo.m creates them; the two grids may have different lengths.

kzpairs     =   makecombo({k_grid, z_grid});

% Putting everything in a grid to make it easier to pass through functions

grid.kz     =   kzpairs;
grid.k      =   k_grid;
grid.z      =   z_grid;
grid.size   =   k_numb*z_numb;

% Rescaling the state collocation nodes to use in Chebyshev polynomials

k_scl       =   scale_poly(klow,khi,k_grid);
z_scl       =   scale_poly(zlow,zhi,z_grid);

% The square matrix which will be used to update coefficients in main loop.
% The function makepolycheb.m generates this square matrix based on orders
% of approximation, and the rescaled collocation nodes

omega       =   makepolycheb(ord, k_scl, z_scl);

% Put matrix into the grid

grid.om     =   omega;

grid.klow   =   klow;
grid.khi    =   khi;
grid.zlow   =   zlow;
grid.zhi    =   zhi;
grid.ord    =   ord;

% Gauss-Hermite quadrature nodes and weights, generated by function
% hernodes.m

gh.size      =   5;
[gh.x, gh.w] =   hernodes(gh.size);

% Initial guess of the coefficients: consume the steady state share of
% output at every state, C = (Css/Yss)*Y. Then
%
%     log m = -nu*(log(Css/Yss) + z + alpha*k),
%
% which is linear in the states. With k = kmid + khalf*kt and z = zhi*zt,
% where kt and zt are the rescaled states, it fits exactly into the order 1
% basis (1, zt, kt, kt*zt). For a higher order these four coefficients are
% placed on the matching basis functions and all others start at zero. The
% basis is ordered with the technology index running fastest.

Css             =   Kss^par.alpha - par.delta*Kss;
share           =   Css/Kss^par.alpha;
kmid            =   (klow + khi)/2;
khalf           =   (khi - klow)/2;
guess           =   -par.nu*[log(share) + par.alpha*kmid; zhi; par.alpha*khalf; 0];
psi             =   zeros((ord_k+1)*(ord_z+1),1);
psi(1)          =   guess(1);       % T0(k)*T0(z)
psi(2)          =   guess(2);       % T0(k)*T1(z)
psi(ord_z+2)    =   guess(3);       % T1(k)*T0(z)
psi(ord_z+3)    =   guess(4);       % T1(k)*T1(z)

% Switch for solution method. 1 is for time iteration, and anything else 
% is for fixed point iteration. Change this to change solution method.

soln_meth = 1; 

%--------------------------------------------------------------------------
%------------------------------ Main Loop ---------------------------------
%--------------------------------------------------------------------------

tic              
              
for psiter = 1:maxiter; 
    
    if soln_meth == 1
        
        output = timeiter_stoch(psi,grid,par,gh);
        
        % Here, output is the marginal utility of today's consumption, as
        % obtained using a nonlinear solver. Unlike the FIXED POINT
        % ITERATION case, it is NOT merely the RHS of the Euler. It is, in
        % fact, the marginal utility obtained AFTER solving the nonlinear
        % equation to obtain the level of today's consumption first.
        
    else
        
        output = iterfun_stoch(psi,par,ord,grid,gh);
        
        % Here, output is merely the numerical integration appearing on the
        % Euler RHS. We take logs because originally we are approximating
        % the log of marginal utility, and that is what we need.
        
    end         

    % Obtain new coefficient estimates using the OLS beta formula
    
    psin = (omega'*omega)\omega'*log(output);
    
    % Calculate distance between previous estimate and new estimate
    
    delpsi = norm(psi - psin);

    % Stop if the iteration has broken down. If a proposed consumption
    % exceeds the available resources at some node, next period's capital
    % is negative, its log is not a real number, and the distance becomes
    % NaN. The comparison with psitol below would then never be true, and
    % the loop would run on until maxiter.

    if ~isfinite(delpsi)
        error('neoclassical_stochastic_main:breakdown', ...
            ['The iteration broke down at iteration %d: the distance is %s. ' ...
             'A proposed consumption exceeded the available resources, so ' ...
             'next period''s capital became negative. Try a smaller lrate, ' ...
             'time iteration (soln_meth = 1), or a better starting guess.'], ...
            psiter, num2str(delpsi));
    end

    % Report progress every 50 iterations, and at convergence

    if mod(psiter, 50) == 0 || delpsi < psitol
        fprintf('after %4d iterations the difference in psi was %6.4e\n', ...
            psiter, delpsi);
    end
    
    % If convergence criteria met, exit loop. Otherwise update using rule. 

    if delpsi < psitol
		break;
    else
		psi = lrate*psin+(1-lrate)*psi;
    end
    

end

toc

%--------------------------- MAIN LOOP ENDS -------------------------------

fprintf('Optimum Chebyshev polynomial coefficient estimates:\n');
fprintf('  %.8f\n', psi);

% Generate time series based on solution obtained, and plot variables

plotting_determ;

%------------------------------ END OF CODE ------------------------------%


