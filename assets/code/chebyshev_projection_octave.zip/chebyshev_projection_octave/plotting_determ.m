%PLOTTING_DETERM  Simulate the solved growth model and plot the results.
%
%   Script called at the end of neoclassical_stochastic_main.m. It uses
%   the workspace of the driver (par, psi, ord, Kss, klow, khi, zlow, zhi).
%
%   What it does
%   ------------
%   1. Draws 2,000 technology shocks from a fixed seed, so every run and
%      every order of approximation sees the same shock history, and
%      builds log Z from the AR(1) process starting at its steady state.
%   2. Starting from steady state capital, it computes consumption each
%      period from the approximated policy,
%          C_t = exp(Omega(k_t, z_t) * psi)^(-1/nu),
%      and capital from the resource constraint. This is a simulation of
%      the policy function, not a solution check.
%   3. Plots periods 501 to 2000, dropping the first 500 periods as burn
%      in, in one figure with three panels on a shared time axis:
%      technology (percent deviation from its mean), consumption and
%      capital, each with its deterministic steady state as a dashed line.
%      The vertical axes adjust to the data. The figure handle is fig;
%      the last lines of the script show how to save it as a vector PDF.
%
%   The file runs unchanged in MATLAB and in GNU Octave. The simulated
%   paths differ between the two, because they draw different random
%   numbers from the same seed.
%
%   The same simulation is available as a function, simulate_growth.m,
%   which the scripts in doc/scripts use to compare orders of
%   approximation on one shock history.
%
%   See also NEOCLASSICAL_STOCHASTIC_MAIN, SIMULATE_GROWTH, MAKEPOLYCHEB.

% Copyright (c) 2015-2026 Anup Mulay. Released under the MIT License (see LICENSE).

close all;

% Plotting parameters

T = 2000;
T1 = 501;

% Variables vectors

kvec = zeros(T,1);
cvec = zeros(T,1);
Kvec = zeros(T,1);
Cvec = zeros(T,1);
zvec = zeros(T,1);
Zvec = zeros(T,1);

% Generating a shock series from a set seed

rng(20110629,'twister')
epsi = randn(T,1)*par.sigma;

% Starting at steady state of shocks

Zvec(1) = 1;
zvec(1) = log(Zvec(1));

% Loop to fill out shock vector based on model parameters

for j = 2:T

    zvec(j) = par.rho*zvec(j-1) + epsi(j);

end

% Starting at steady state of capital

Kvec(1) = Kss;
kvec(1) = log(Kvec(1));

% Filling out vectors of endogenous variables based on model equations

for i = 1:T

    k00 = scale_poly(klow,khi,kvec(i));
    z00 = scale_poly(zlow,zhi,zvec(i));

    temp        = makepolycheb(ord,[k00 z00])*psi;

    extemp      = exp(temp);

    Cvec(i)     = (extemp)^(-1/par.nu);

    cvec(i)     = log(Cvec(i));

    Zvec(i)     = exp(zvec(i));

    % Next period's capital, for all but the last period

    if i < T
        Kvec(i+1)  =   Zvec(i)*Kvec(i)^par.alpha + ...
           (1 - par.delta)*Kvec(i) - Cvec(i);
        kvec(i+1)  =   log(Kvec(i+1));
    end

end

%--------------------------------------------------------------------------

% Plot: one figure with three panels sharing the time axis. Technology is
% the shock that drives the economy; consumption and capital are shown in
% levels, each against its deterministic steady state (dashed).

Css_plot = Kss^par.alpha - par.delta*Kss;      % deterministic steady state
t        = (T1:T)';

col_main = [ 31  58  96]/255;                  % dark blue: simulated series
col_ss   = [150 150 150]/255;                  % grey: steady state
col_z    = [ 90  90  90]/255;                  % dark grey: technology
fs       = 9;                                  % font size in points
lw       = 1.1;                                % line width of the series

% The plot uses only commands that MATLAB and GNU Octave share (subplot,
% plot, line, legend), so the same file runs in both.

fig = figure('Name', 'Simulation', 'Color', 'w', 'Units', 'centimeters', ...
             'Position', [2 2 16 15]);

% (a) technology, in percent deviation from its mean
ax1 = subplot(3, 1, 1);
plot(ax1, t, 100*zvec(t), '-', 'Color', col_z, 'LineWidth', 0.8);
hold(ax1, 'on');
line(ax1, [T1 T], [0 0], 'LineStyle', '--', 'Color', col_ss, 'LineWidth', 0.8);
title(ax1, '(a) Technology, percent deviation from its mean (100 log Z_t)');

% (b) consumption
ax2 = subplot(3, 1, 2);
h_sim = plot(ax2, t, Cvec(t), '-', 'Color', col_main, 'LineWidth', lw);
hold(ax2, 'on');
h_ss  = line(ax2, [T1 T], [Css_plot Css_plot], 'LineStyle', '--', ...
             'Color', col_ss, 'LineWidth', 0.8);
title(ax2, '(b) Consumption C_t');

% (c) capital
ax3 = subplot(3, 1, 3);
plot(ax3, t, Kvec(t), '-', 'Color', col_main, 'LineWidth', lw);
hold(ax3, 'on');
line(ax3, [T1 T], [Kss Kss], 'LineStyle', '--', 'Color', col_ss, 'LineWidth', 0.8);
title(ax3, '(c) Capital K_t');
xlabel(ax3, 'Period');

% Vertical limits: the data and the steady state line, plus 5 percent
% padding on each side
ydata = {100*zvec(t), Cvec(t), Kvec(t)};
yss   = [0, Css_plot, Kss];
axs   = [ax1 ax2 ax3];

% Common style for all panels: thin dark grey axes, short outward ticks,
% no box, a light horizontal grid, plain titles
for n = 1:3
    lo = min([ydata{n}; yss(n)]);
    hi = max([ydata{n}; yss(n)]);
    pad = 0.05*(hi - lo);
    set(axs(n), 'FontSize', fs, 'LineWidth', 0.6, 'TickDir', 'out', ...
        'TickLength', [0.008 0.008], 'Box', 'off', ...
        'XColor', [0.2 0.2 0.2], 'YColor', [0.2 0.2 0.2], ...
        'XGrid', 'off', 'YGrid', 'on', 'GridColor', [0.85 0.85 0.85], ...
        'GridAlpha', 1, 'XLim', [T1 T], 'YLim', [lo - pad, hi + pad]);
    set(get(axs(n), 'Title'), 'FontWeight', 'normal', 'FontSize', fs + 0.5);
end
set([ax1 ax2], 'XTickLabel', []);              % shared time axis

% Place the three panels explicitly, with equal heights, leaving room at
% the top for the legend (positions are fractions of the figure)
bottoms = [0.66 0.37 0.08];
for n = 1:3
    set(axs(n), 'Position', [0.10, bottoms(n), 0.86, 0.20]);
end

% Legend above the first panel, its left edge aligned with the panels.
% It is not centred: Octave reports the legend's width too small when it
% prints, so a centred legend would run off the right edge.
lgd = legend(ax2, [h_sim h_ss], ...
    {sprintf('Simulation, order %d in capital and %d in technology', ord(1), ord(2)), ...
     'Deterministic steady state'}, 'Orientation', 'horizontal');
legend(ax2, 'boxoff');
set(lgd, 'FontSize', fs, 'Units', 'normalized');
drawnow;                                       % so the legend size is final
lp = get(lgd, 'Position');
set(lgd, 'Position', [0.10, 0.955 - lp(4)/2, lp(3), lp(4)]);

% To save the figure as a vector PDF for a paper or slides, run these
% two lines. The first makes the page the size of the figure.
%   set(fig, 'PaperUnits', 'centimeters', 'PaperSize', [16 15], 'PaperPosition', [0 0 16 15]);
%   print(fig, 'simulation.pdf', '-dpdf')
