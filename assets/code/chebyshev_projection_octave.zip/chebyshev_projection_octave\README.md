# Chebyshev projection for the stochastic neoclassical growth model (GNU Octave)

This folder contains code that I wrote to solve the stochastic neoclassical growth model by projection. This version runs in GNU Octave, which is free. I approximate the log of marginal utility of consumption with a tensor product of Chebyshev polynomials in log capital and log technology. The coefficients are found by collocation at the Chebyshev nodes. The expectation in the Euler equation is computed by Gauss-Hermite quadrature.

The code offers two ways to update the coefficients. Fixed point iteration takes the right hand side of the Euler equation as the new left hand side. It is cheap per iteration. Time iteration solves for today's consumption at each node with a nonlinear solver, given tomorrow's policy. It is more robust far from the solution. Both converge to the same coefficients.

A separate version for MATLAB is available on my website.

## How to run it

1. Install GNU Octave from https://octave.org/download. I tested the code in Octave 11.3.
2. Open Octave and change its current folder to this folder.
3. Run `neoclassical_stochastic_main`.

The script prints its progress every 50 iterations and then the converged coefficients. It ends by simulating the model for 2,000 periods and plotting technology, consumption and capital.

The solution matches the MATLAB version to ten decimal places. The simulated paths in the plot differ from the MATLAB version. The reason is that Octave and MATLAB produce different random numbers from the same seed.

## Settings

All settings are near the top of `neoclassical_stochastic_main.m`.

- `soln_meth` chooses the method. A value of 1 means time iteration. Any other value means fixed point iteration. The default is 1.
- `ord_k` and `ord_z` set the order of approximation in capital and in technology. They may differ. The default is 2 in each state.
- `psitol`, `lrate` and `maxiter` control convergence, damping and the iteration limit.
- The model parameters are in the structure `par`.

With the default settings, fixed point iteration converges in 618 iterations and time iteration in 635.

## Files

| File | Role |
|---|---|
| `neoclassical_stochastic_main.m` | Main script. Sets up the problem, runs the loop and calls the plot. |
| `chebgrid.m` | Chebyshev collocation nodes on an interval. |
| `makecombo.m` | All combinations of the nodes of several states. |
| `scale_poly.m` | Maps points from a state's interval to [-1, 1]. |
| `chebpol.m` | Chebyshev polynomials evaluated at given points. |
| `makepolycheb.m` | Two dimensional tensor product Chebyshev basis. |
| `hernodes.m` | Gauss-Hermite quadrature nodes and weights. |
| `iterfun_stoch.m` | One step of fixed point iteration. |
| `timeiter_stoch.m` | One step of time iteration. |
| `titer_func.m` | Euler equation residual that the solver drives to zero. |
| `num_int_ti.m` | Expected right hand side of the Euler equation. |
| `csolve.m` | Nonlinear equation solver by Christopher Sims. |
| `plotting_determ.m` | Simulates the solved model and plots the results. |

## Credits and licence

`csolve.m` is the work of Christopher Sims and the Dynare Team. It is distributed under the GNU General Public License, version 3 or later. The full text is in `LICENSE-GPL-3.0.txt`. The structure of `chebpol.m` and `makepolycheb.m` follows Wouter den Haan's teaching code on projection methods. I rewrote both files for this code.

All other files are my own work. They are released under the MIT License, which is in `LICENSE`.

Anup Mulay, https://anupmulay.github.io/
