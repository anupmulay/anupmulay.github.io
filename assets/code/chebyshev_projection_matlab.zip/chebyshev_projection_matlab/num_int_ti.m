function num_exp = num_int_ti(init_c,gh,par,init_k,init_z,coef,klow,khi,...
    zlow,zhi,ord)
%NUM_INT_TI  Expected right hand side of the Euler equation by Gauss-Hermite quadrature.
%
%   num_exp = num_int_ti(init_c, gh, par, init_k, init_z, coef, klow, khi,
%   zlow, zhi, ord) returns
%
%       E[ beta C'^(-nu) (1 - delta + alpha Z' K'^(alpha-1)) ]
%
%   for a given level of today's consumption init_c at the state
%   (init_k, init_z) in logs. Next period's capital follows from the
%   resource constraint, next period's shock from the AR(1) process, and
%   next period's consumption from the current approximation coef.
%
%   Quadrature
%   ----------
%   Gauss-Hermite quadrature integrates against the weight exp(-x^2), but
%   the shock has the normal density (1/(sigma sqrt(2 pi))) exp(-eps^2/(2 sigma^2)).
%   The change of variables eps = sqrt(2) sigma x, together with its
%   Jacobian, turns the expectation into
%
%       E[f(eps)] = (1/sqrt(pi)) sum_j w_j f(sqrt(2) sigma x_j),
%
%   which is what the loop below computes.
%
%   Role in the method
%   ------------------
%   Used inside the residual function titer_func.m during time iteration.
%   It differs from the inner loop of iterfun_stoch.m only in taking
%   today's consumption as an argument (the solver's candidate) instead of
%   computing it from the coefficients.
%
%   Inputs
%     init_c      candidate level of today's consumption
%     gh          Gauss-Hermite nodes gh.x, weights gh.w, number gh.size
%     par         structure of parameters
%     init_k      log capital today
%     init_z      log technology today
%     coef        current coefficients of log marginal utility
%     klow, khi   bounds of log capital
%     zlow, zhi   bounds of log technology
%     ord         1 x 2 vector of polynomial orders [ord_k ord_z]
%
%   Outputs
%     num_exp     the expectation, a scalar
%
%   See also TITER_FUNC, TIMEITER_STOCH, HERNODES.

% Copyright (c) 2015-2026 Anup Mulay. Released under the MIT License (see LICENSE).

temp    =   zeros(gh.size,1);

% Take as input the level of consumption as obtained in timeiter_stoch.m
% through titer_func.m, and obtain the log of next period's capital stock
% so as to use it to approximate next period's log marginal utility of
% consumption

k_next = log(exp(init_z)*exp(init_k)^par.alpha + ...
    (1-par.delta)*exp(init_k) - init_c);

% Rescale next period's log capital stock to use inside the GH nodes loop,
% where the future value of technology will be different at each node.

k_next_res = scale_poly(klow,khi,k_next);

for j = 1:gh.size,


        % Compute next period's technology shock using the GH nodes and the
        % AR(1) expression

        x1           =   par.rho*init_z + par.sigma*gh.x(j)*sqrt(2);

        % Rescale to use in polynomial approximation

        xx          =   scale_poly(zlow,zhi,x1);

        % Approximate log marginal utility of next period consumption, and
        % back out level of consumption

        poly2       =   makepolycheb(ord, [k_next_res xx])*coef;

        expoly2     =   exp(poly2);

        C1          =   expoly2^(-1/par.nu);

        % Compute the RHS at each GH node

        temp(j,1)   =   gh.w(j)*par.beta*(1-par.delta + ...
            par.alpha*exp(x1)*exp(k_next)^(par.alpha-1))*C1^(-par.nu)/sqrt(pi);


end

% Expectation term on RHS computed using numerical integration

num_exp = sum(temp);


end
