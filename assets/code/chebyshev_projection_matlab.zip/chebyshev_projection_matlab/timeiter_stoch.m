function output = timeiter_stoch(coef,grid,par,gh)
%TIMEITER_STOCH  One step of time iteration on the Euler equation.
%
%   output = timeiter_stoch(coef, grid, par, gh) returns, at every
%   collocation node, the marginal utility of today's consumption that
%   solves the Euler equation exactly, taking next period's policy as
%   given by the current approximation coef.
%
%   At each node s = (k, z) it starts from the consumption implied by coef
%   and calls the nonlinear solver csolve.m on titer_func.m, which returns
%   the Euler residual
%
%       C^(-nu) - E[ beta C'^(-nu) (1 - delta + alpha Z' K'^(alpha-1)) ],
%
%   where K' depends on the candidate C through the resource constraint
%   and the expectation is computed in num_int_ti.m by Gauss-Hermite
%   quadrature.
%
%   Role in the method
%   ------------------
%   This is the TIME ITERATION variant (soln_meth = 1 in
%   neoclassical_stochastic_main.m). The difference from fixed point
%   iteration (iterfun_stoch.m) is that today's consumption is a choice:
%   the solver moves C until both sides of the Euler equation are equal,
%   so today's policy is optimal given tomorrow's. This mirrors backward
%   induction on the policy function and is the more robust of the two
%   variants. The driver takes logs of the output and projects them onto
%   the basis, exactly as in the fixed point variant.
%
%   Solver failures
%   ---------------
%   csolve.m returns a flag rc with its answer:
%     rc = 0   success: the Euler residual |F| fell below 1e-12.
%     rc = 4   failure: csolve stopped after 1,000 iterations without
%              getting |F| below 1e-12. Its answer is then only the point
%              where it stopped, not a root.
%   A second kind of failure is a complex answer. It arises when a trial
%   consumption exceeds what is available, so next period's capital is
%   negative and its log is complex.
%
%   In either case this function stops with the error
%   'timeiter_stoch:csolve', naming the node, its state, the flag and the
%   answer. A failed node would otherwise pass silently into the new
%   coefficients. Ways to fix it:
%     1. Start closer to the solution. A poor starting guess for coef
%        can ask for impossible consumption at some node. Use a better
%        guess, or run fixed point iteration first and start time
%        iteration from its coefficients.
%     2. Damp more. Lower lrate in the driver (for example to 0.3), so
%        each iteration moves the coefficients less.
%     3. Check the domain. If the node or next period's capital lies far
%        outside [klow, khi] or [zlow, zhi], the polynomial extrapolates
%        and can give nonsense. Widen or recentre the domain.
%     4. Check the parameters. Values that make the model explode, or
%        that have no steady state, have no solution to find.
%
%   Inputs
%     coef  current coefficients of log marginal utility
%     grid  structure: kz, om, klow, khi, zlow, zhi, size (see the driver)
%     par   structure of parameters: nu, alpha, beta, delta, sigma, rho
%     gh    structure: x, w (Gauss-Hermite nodes and weights), size
%
%   Outputs
%     output  grid.size x 1 vector: marginal utility C^(-nu) at each node
%
%   See also NEOCLASSICAL_STOCHASTIC_MAIN, TITER_FUNC, NUM_INT_TI, CSOLVE.

% Copyright (c) 2015-2026 Anup Mulay. Released under the MIT License (see LICENSE).

% Vector for values at all grid points

yvec     =   zeros(grid.size,1);

for i = 1:grid.size,

    % For each point of approximation in the state space, pick out the
    % initial values of both states so as to approximate the marginal
    % utility

    k0  =   grid.kz(i,1);
    z0  =   grid.kz(i,2);

    % Generate a polynomial approximation at this point in state space.
    % Here we directly use rows of the omega matrix. Alternatively, we
    % could rescale the state space points using scale_poly.m, and then use
    % makepolycheb.m to create the approximation for identical results.

    poly = grid.om(i,:)*coef;

    expoly  =   exp(poly);

    C0 = expoly^(-1/par.nu);

    % Now, instead of calculating next period capital using this and
    % carrying out the steps in FIXED POINT ITERATION, we use the solver
    % csolve.m to obtain values for consumption by solving the nonlinear
    % expression that the Euler becomes

    [new_val, rc] = csolve(@titer_func,C0,[],1e-12,1000,par,k0,z0,coef,...
        gh,grid);

    % Stop if the solver failed at this node. rc = 4 means csolve hit
    % 1,000 iterations without |F| < 1e-12; a complex answer means a trial
    % consumption made next period's capital negative. See "Solver
    % failures" in the help text above for what the flag means and how
    % to fix it.

    if rc ~= 0 || ~isreal(new_val)
        error('timeiter_stoch:csolve', ...
            ['csolve failed at node %d (K = %.4g, z = %.4g): return code %d, ' ...
             'consumption %s. rc = 4 means no root within 1,000 iterations; ' ...
             'a complex value means consumption exceeded available resources. ' ...
             'Try a better starting guess, a smaller lrate, or a wider domain ' ...
             '(see help timeiter_stoch).'], ...
            i, exp(k0), z0, rc, num2str(new_val));
    end

    % The output of the solver, as can be seen inside titer_func.m,
    % is the 'level' of consumption today for each grid point

    yvec(i,1) = new_val;

end

% Since we are interested in using the log of the marginal utility, we
% compute the marginal utility here, and log it in the main function to be
% consistent with the fixed point methodology

output = yvec.^(-par.nu);

end
