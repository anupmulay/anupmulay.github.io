function T = chebpol(ord, p)
%CHEBPOL  Chebyshev polynomials T_0 ... T_ord evaluated at given points.
%
%   T = chebpol(ord, p) returns a numel(p) x (ord+1) matrix whose column
%   i+1 holds T_i(p), the Chebyshev polynomial of the first kind of
%   degree i, evaluated at every element of p.
%
%   The polynomials follow the three term recurrence
%
%       T_0(x) = 1,   T_1(x) = x,   T_{i+1}(x) = 2x T_i(x) - T_{i-1}(x).
%
%   Role in the method
%   ------------------
%   This is the one dimensional basis of the approximation. A policy
%   function in one state is approximated as T(s)*theta, where theta is
%   the coefficient vector. For several states, makepolycheb.m combines
%   these one dimensional bases into a tensor product basis.
%
%   Inputs
%     ord   highest polynomial degree (nonnegative integer)
%     p     points in [-1, 1] (rescale with scale_poly.m first)
%
%   Outputs
%     T     numel(p) x (ord+1) matrix of basis function values
%
%   The structure of this function follows Wouter den Haan's teaching code
%   on projection methods; this version was rewritten for this repository.
%
%   See also MAKEPOLYCHEB, SCALE_POLY.

% Copyright (c) 2015-2026 Anup Mulay. Released under the MIT License (see LICENSE).

p = p(:);
T = ones(numel(p), ord + 1);
if ord >= 1
    T(:, 2) = p;
end
for i = 3:ord + 1
    T(:, i) = 2 * p .* T(:, i - 1) - T(:, i - 2);
end

end
