function x = chebgrid(a, b, n)
%CHEBGRID  Chebyshev collocation nodes on an arbitrary interval [a, b].
%
%   x = chebgrid(a, b, n) returns the n zeros of the Chebyshev polynomial
%   T_n, mapped linearly from [-1, 1] to [a, b]:
%
%       x_i = a + (b - a)/2 * (1 + cos((2i - 1)*pi / (2n))),   i = 1..n.
%
%   The nodes are returned in descending order.
%
%   Role in the method
%   ------------------
%   These are the points at which the model's equilibrium conditions are
%   imposed (collocation). Chebyshev zeros cluster towards the ends of the
%   interval, which avoids the large oscillations that evenly spaced nodes
%   produce near the boundaries (Runge's phenomenon) and makes the
%   interpolation error nearly uniform. With n = order + 1 nodes per state
%   the projection matrix Omega is square and well conditioned, because the
%   Chebyshev polynomials are discretely orthogonal on these nodes.
%
%   Inputs
%     a   lower bound of the state's domain
%     b   upper bound of the state's domain
%     n   number of nodes (use order of approximation + 1)
%
%   Outputs
%     x   n x 1 vector of nodes in [a, b]
%
%   See also SCALE_POLY, MAKECOMBO, MAKEPOLYCHEB.

% Copyright (c) 2015-2026 Anup Mulay. Released under the MIT License (see LICENSE).

temp = cos((2*(1:n)' - 1)*pi/2/n);
x = (temp + 1)*((b - a)/2) + a;

end
