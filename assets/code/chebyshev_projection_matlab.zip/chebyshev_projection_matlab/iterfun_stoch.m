function output = iterfun_stoch(coef,par,ord,grid,gh)
%ITERFUN_STOCH  One step of fixed point iteration on the Euler equation.
%
%   output = iterfun_stoch(coef, par, ord, grid, gh) evaluates, at every
%   collocation node, the right hand side of the Euler equation implied by
%   the current approximation coef, and returns it as the updated value of
%   today's marginal utility of consumption.
%
%   At each node s = (k, z):
%     1. Today's consumption from the approximation:
%            C = exp(Omega(s)*coef)^(-1/nu).
%     2. Next period's capital from the resource constraint:
%            K' = exp(z) exp(k)^alpha + (1 - delta) exp(k) - C.
%     3. For each Gauss-Hermite node x_j, next period's shock
%        z'_j = rho z + sqrt(2) sigma x_j, next period's consumption
%        C'_j from the same approximation at (log K', z'_j), and
%            E[RHS] = (1/sqrt(pi)) sum_j w_j beta C'_j^(-nu)
%                     (1 - delta + alpha exp(z'_j) K'^(alpha-1)).
%
%   Role in the method
%   ------------------
%   This is the FIXED POINT ITERATION variant (soln_meth ~= 1 in
%   neoclassical_stochastic_main.m). Unlike time iteration, it does not
%   solve for today's consumption: both today's and tomorrow's policies
%   come from the current coefficients, and the right hand side of the
%   Euler equation simply becomes the new left hand side. Each iteration
%   is cheap (no nonlinear solver), at the cost of being less robust far
%   from the solution. The driver takes logs of the output and projects
%   them onto the basis to obtain the new coefficients.
%
%   Inputs
%     coef  current coefficients of log marginal utility, ((ord_k+1)*(ord_z+1)) x 1
%     par   structure of parameters: nu, alpha, beta, delta, sigma, rho
%     ord   1 x 2 vector of polynomial orders [ord_k ord_z]
%     grid  structure: kz (node combinations), om (basis matrix Omega),
%           klow, khi, zlow, zhi (state bounds), size (number of nodes)
%     gh    structure: x, w (Gauss-Hermite nodes and weights), size
%
%   Outputs
%     output  grid.size x 1 vector: updated marginal utility at each node
%
%   See also NEOCLASSICAL_STOCHASTIC_MAIN, TIMEITER_STOCH, HERNODES.

% Copyright (c) 2015-2026 Anup Mulay. Released under the MIT License (see LICENSE).

% Vector for values at all grid points of collocation

yvec     =   zeros(grid.size,1);

% Vector for all points of numerical integration

temp    =   zeros(gh.size,1);

for i = 1:grid.size,

    % For each point of approximation in the state space, pick out the
    % initial values of both states so as to approximate the marginal
    % utility

    k0  =   grid.kz(i,1);
    z0  =   grid.kz(i,2);

    % Generate a polynomial approximation at this point in state space.
    % Here we directly use rows of the omega matrix. Alternatively, we
    % could rescale the state space points using scale_poly.m, and then use
    % makepolycheb.m to create the approximation for identical results.

    poly = grid.om(i,:)*coef;

    % Since the approximation is the log of the marginal utility, we now
    % back out the actual level of consumption implied, so we can calculate
    % the capital stock for next period from the law of motion

    expoly  =   exp(poly);

    C0 = expoly^(-1/par.nu);


    K1  =   exp(z0)*exp(k0)^par.alpha + (1 - par.delta)*exp(k0) - C0;

    % Take logs of the next period capital stock, so as to rescale it and
    % use it to generate an approximation of next period's log of marginal
    % utility

    k1  =   log(K1);

    k11 =   scale_poly(grid.klow,grid.khi,k1);

    % Now that we have the states for next period, we can use them to
    % generate an approximation for next period consumption, and ultimately
    % the expectation term on the RHS using numerical integration

    for j = 1:gh.size,

        % Compute next period's exogenous variable for integration

        x1           =   par.rho*z0 + par.sigma*gh.x(j)*sqrt(2);

        % Rescale

        xx          =   scale_poly(grid.zlow,grid.zhi,x1);

        % Generate approximation for log marginal utility, and back out
        % consumption

        poly2       =   makepolycheb(ord, [k11 xx])*coef;

        expoly2     =   exp(poly2);

        C1          =   expoly2^(-1/par.nu);

        % RHS expectation at each GH node

        temp(j,1)   =   gh.w(j)*par.beta*(1-par.delta + ...
            par.alpha*exp(x1)*K1^(par.alpha-1))*C1^(-par.nu)/sqrt(pi);


    end

    % Sum over all quadrature nodes to get expectation of RHS

    yvec(i,1)    =   sum(temp);

end

output = yvec;

end
