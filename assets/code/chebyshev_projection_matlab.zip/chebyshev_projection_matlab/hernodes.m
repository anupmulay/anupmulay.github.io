function [x, w] = hernodes(n)
%HERNODES  Gauss-Hermite quadrature nodes and weights.
%
%   [x, w] = hernodes(n) returns the n nodes x and weights w of the
%   Gauss-Hermite rule for the weighting function exp(-x^2):
%
%       integral of f(x)*exp(-x^2) dx over the real line  ~  sum_j w(j)*f(x(j))
%
%   The rule is exact for polynomials f of degree up to 2n-1.
%
%   Role in the method
%   ------------------
%   The Euler equation contains a conditional expectation over next
%   period's technology shock, z' = rho*z + eps with eps ~ N(0, sigma^2).
%   Substituting eps = sqrt(2)*sigma*x turns that expectation into
%
%       E[g(z')] = (1/sqrt(pi)) * sum_j w(j) * g(rho*z + sqrt(2)*sigma*x(j)),
%
%   which is how iterfun_stoch.m and num_int_ti.m use these nodes. A
%   handful of nodes (five in the drivers) is enough because the
%   integrand is smooth.
%
%   Algorithm
%   ---------
%   Golub and Welsch (1969): the nodes are the eigenvalues of the
%   symmetric tridiagonal Jacobi matrix of the Hermite three term
%   recurrence (zero diagonal, off diagonal sqrt(k/2) for k = 1..n-1), and
%   each weight is sqrt(pi) times the squared first component of the
%   corresponding normalised eigenvector. Nodes are returned in
%   descending order, symmetric about zero.
%
%   Inputs
%     n   number of quadrature nodes (positive integer)
%
%   Outputs
%     x   n x 1 vector of nodes, descending
%     w   n x 1 vector of weights, summing to sqrt(pi)
%
%   This file replaces an earlier third party routine and is written from
%   the published algorithm.
%
%   See also ITERFUN_STOCH, NUM_INT_TI.

% Copyright (c) 2015-2026 Anup Mulay. Released under the MIT License (see LICENSE).

k      = (1:n-1)';
offd   = sqrt(k/2);
J      = diag(offd, 1) + diag(offd, -1);
[V, D] = eig(J);
[x, order] = sort(diag(D), 'descend');
w      = sqrt(pi) * (V(1, order)').^2;

% Impose exact symmetry, which the eigen solver only delivers up to
% rounding error.
x = (x - flipud(x)) / 2;
w = (w + flipud(w)) / 2;

end
