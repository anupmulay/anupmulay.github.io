function yf = titer_func(x,par,k0,z0,coef,gh,grid)
%TITER_FUNC  Euler equation residual at one node, as a function of consumption.
%
%   yf = titer_func(x, par, k0, z0, coef, gh, grid) returns
%
%       yf = c^(-nu) - E[ beta C'^(-nu) (1 - delta + alpha Z' K'^(alpha-1)) ]
%
%   for each candidate level of today's consumption c in x, at the state
%   (k0, z0). The expectation, which depends on c through next period's
%   capital, is computed by num_int_ti.m using the current coefficients
%   coef for next period's policy.
%
%   Role in the method
%   ------------------
%   This is the function that csolve.m drives to zero in time iteration
%   (timeiter_stoch.m). csolve may pass several candidates at once as
%   columns of x, so the function loops over columns. To solve a model with
%   more equations or more unknowns at each node, this is the file to
%   extend: each row of x is one unknown and each row of yf one equation.
%
%   Inputs
%     x     1 x m matrix of candidate consumption levels (one per column)
%     par   structure of parameters
%     k0    log capital at the current node
%     z0    log technology at the current node
%     coef  current policy coefficients (fixed during the solve)
%     gh    Gauss-Hermite nodes and weights
%     grid  grid structure with the state bounds and orders (grid.ord)
%
%   Outputs
%     yf    1 x m matrix of Euler residuals
%
%   See also TIMEITER_STOCH, NUM_INT_TI, CSOLVE.

% Copyright (c) 2015-2026 Anup Mulay. Released under the MIT License (see LICENSE).

[rows,cols]=size(x);

j=1;

while j<=cols;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% variables in the system:

c    = x(1,j);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% DEFINE SYSTEM: The equations which define the system are put in here. The
% equations can be in functional form, as is the case here.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

yf(1,j) =   c^(-par.nu) - num_int_ti(c,gh,par,k0,z0,coef,...
    grid.klow,grid.khi,grid.zlow,grid.zhi,grid.ord);

j=j+1;

end;

end
