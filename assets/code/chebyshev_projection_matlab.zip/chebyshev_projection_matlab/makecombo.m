function grid_comb = makecombo(kz, order) 
%MAKECOMBO  All combinations of grid points across several states.
%
%   grid_comb = makecombo(grids) takes a cell array whose elements are the
%   grids of the individual states, one column vector each, and returns
%   every combination of them, one combination per row. The grids may have
%   different lengths. The first state varies slowest and the last state
%   fastest. For two states with nodes k1, k2, k3 and z1, z2 the result is
%
%       [k1 z1; k1 z2; k2 z1; k2 z2; k3 z1; k3 z2].
%
%   grid_comb = makecombo(kz, order) is the older call: a matrix kz whose
%   columns are the grids of the states, all of the same length. The
%   second argument is no longer needed and is ignored.
%
%   This ordering matches the rows of the tensor product basis built by
%   makepolycheb.m, so row i of grid_comb is the state at which row i of
%   Omega is evaluated.
%
%   Role in the method
%   ------------------
%   The equilibrium conditions are evaluated at every point of the tensor
%   grid. The solution routines loop over the rows of grid_comb (stored as
%   grid.kz) and read the levels of the states from it. It works for any
%   number of states, which replaced typing out the pairs by hand.
%
%   Inputs
%     grids   1 x d cell array; element j is the grid of state j (unscaled)
%     or
%     kz      n x d matrix; column j is the grid of state j (unscaled)
%     order   (older call only, ignored) number of grid points per state
%
%   Outputs
%     grid_comb   (n_1 * ... * n_d) x d matrix of all grid point combinations
%
%   See also CHEBGRID, MAKEPOLYCHEB.

% Copyright (c) 2015-2026 Anup Mulay. Released under the MIT License (see LICENSE).

if iscell(kz)
    grids = kz;                    % one grid per state, any lengths
else
    grids = num2cell(kz, 1);       % older call: one column per state
end

d = numel(grids);
n = cellfun(@numel, grids);
grid_comb = zeros(prod(n), d);

for j = 1:d
    inner = prod(n(j+1:end));      % each value repeats once per combination of later states
    outer = prod(n(1:j-1));        % the whole block repeats once per combination of earlier states
    grid_comb(:, j) = repmat(repelem(grids{j}(:), inner), outer, 1);
end

end
