function x = scale_poly(a, b, n)
%SCALE_POLY  Map points from [a, b] to [-1, 1].
%
%   x = scale_poly(a, b, n) applies the linear map
%
%       x = 2*(n - a)/(b - a) - 1
%
%   to every element of n, so that a maps to -1 and b maps to 1.
%
%   Role in the method
%   ------------------
%   Chebyshev polynomials are defined on [-1, 1], while the model's states
%   (log capital, log technology) live on their own intervals. Every state
%   value is passed through this function before chebpol.m or
%   makepolycheb.m evaluates the basis at it. This includes points that
%   are not collocation nodes, such as next period's capital stock and the
%   technology shock at each quadrature node. Points that fall outside
%   [a, b] map outside [-1, 1]; the polynomial is then extrapolated, which
%   is why the state bounds should be wide enough to contain the ergodic
%   set.
%
%   Inputs
%     a   lower bound of the state's domain
%     b   upper bound of the state's domain
%     n   scalar, vector or matrix of points to rescale
%
%   Outputs
%     x   rescaled points, same size as n
%
%   See also CHEBGRID, CHEBPOL, MAKEPOLYCHEB.

% Copyright (c) 2015-2026 Anup Mulay. Released under the MIT License (see LICENSE).

x = 2*(n - a)/(b - a) - 1;

end
