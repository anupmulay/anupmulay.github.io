function xmat = makepolycheb(ord, x, z)
%MAKEPOLYCHEB  Two dimensional tensor product Chebyshev basis.
%
%   xmat = makepolycheb(ord, x) evaluates the complete tensor product
%   basis T_i(k)*T_j(z), i = 0..ord(1), j = 0..ord(2), where k = x(:,1)
%   and z = x(:,2) are already rescaled to [-1, 1].
%
%   xmat = makepolycheb(ord, k, z) does the same with the two grids
%   passed separately, as column vectors. They may have different
%   lengths, which is needed when the two orders differ.
%
%   Columns are ordered with the second state running fastest:
%   T_0*T_0, T_0*T_1, ..., T_0*T_ord(2), T_1*T_0, ..., T_ord(1)*T_ord(2).
%
%   Because the product is a Kronecker product of the two one dimensional
%   bases, the rows also form a tensor grid. With n points in each column
%   of x, xmat has n^2 rows ordered (k1,z1), (k1,z2), ..., (kn,zn),
%   that is every combination of the k nodes with the z nodes, in the
%   same order as makecombo.m. With a single point (one row of x), xmat is
%   one row: the basis at that point.
%
%   Role in the method
%   ------------------
%   Called on the Chebyshev collocation nodes, it produces the square
%   matrix Omega used to project values at the nodes onto coefficients,
%   theta = (Omega'*Omega) \ Omega' * y. Called on a single point, such as
%   next period's state at a quadrature node, xmat*theta evaluates the
%   approximated policy function there.
%
%   Inputs
%     ord   1 x 2 vector of polynomial orders [ord_k ord_z]
%     x     n x 2 matrix of rescaled points, columns [k z]
%     or
%     x, z  rescaled grids of k (n_k x 1) and z (n_z x 1), passed separately
%
%   Outputs
%     xmat  (n^2, or n_k*n_z) x (ord(1)+1)*(ord(2)+1) basis matrix
%
%   The structure of this function follows Wouter den Haan's teaching code
%   on projection methods; this version was rewritten for this repository.
%
%   See also CHEBPOL, MAKECOMBO, SCALE_POLY.

% Copyright (c) 2015-2026 Anup Mulay. Released under the MIT License (see LICENSE).

if nargin == 3       % separate grids for the two states, lengths may differ
    xmat = kron(chebpol(ord(1), x), chebpol(ord(2), z));
else
    xmat = kron(chebpol(ord(1), x(:, 1)), chebpol(ord(2), x(:, 2)));
end

end
